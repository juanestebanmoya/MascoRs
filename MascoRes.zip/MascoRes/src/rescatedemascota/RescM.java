/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rescatedemascota;

/**
 *
 * @author Diego
 */
public class RescM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          vista  vista  = new vista ();
          vista.setVisible(true);
        
    }
    
}
