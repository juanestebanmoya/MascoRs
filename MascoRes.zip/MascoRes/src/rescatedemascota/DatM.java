/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rescatedemascota;

/**
 *
 * @author Diego
 */
public class DatM 
{
    private String NombreMascota ;
    private String RazaMascota;
    private String ColorMascota;
    private String EdadMascota;
    private String NivelEntrenamiento;
    private String ConfiGatPerr ;
    private String toxoplamosis ;
   
    public DatM(String NombreMascota, String RazaMascota, String ColorMascota, String EdadMascota, String NivelEntrenamiento, String ConfiGatPerr, String toxoplamosis) {
        this.NombreMascota = NombreMascota;
        this.RazaMascota = RazaMascota;
        this.ColorMascota = ColorMascota;
        this.EdadMascota = EdadMascota;
        this.NivelEntrenamiento = NivelEntrenamiento;
        this.ConfiGatPerr = ConfiGatPerr;
        this.toxoplamosis = toxoplamosis;
    }

    public String getNombreMascota() {
        return NombreMascota;
    }

    public void setNombreMascota(String NombreMascota) {
        this.NombreMascota = NombreMascota;
    }

    public String getRazaMascota() {
        return RazaMascota;
    }

    public void setRazaMascota(String RazaMascota) {
        this.RazaMascota = RazaMascota;
    }

    public String getColorMascota() {
        return ColorMascota;
    }

    public void setColorMascota(String ColorMascota) {
        this.ColorMascota = ColorMascota;
    }

    public String getEdadMascota() {
        return EdadMascota;
    }

    public void setEdadMascota(String EdadMascota) {
        this.EdadMascota = EdadMascota;
    }

    public String getNivelEntrenamiento() {
        return NivelEntrenamiento;
    }

    public void setNivelEntrenamiento(String NivelEntrenamiento) {
        this.NivelEntrenamiento = NivelEntrenamiento;
    }

    public String getConfiGatPerr() {
        return ConfiGatPerr;
    }

    public void setConfiGatPerr(String ConfiGatPerr) {
        this.ConfiGatPerr = ConfiGatPerr;
    }

    public String getToxoplamosis() {
        return toxoplamosis;
    }

    public void setToxoplamosis(String toxoplamosis) {
        this.toxoplamosis = toxoplamosis;
    }
   
  

   
    
}
